# Tovarka26 Start Bot

Telegram-бот «Товарка START» для міні-продукту за 399 грн.

## Railway Variables

Обов’язкові:

- `TELEGRAM_BOT_TOKEN` — токен з BotFather
- `OPENAI_API_KEY` — ключ OpenAI
- `DATABASE_URL` — PostgreSQL URL з Railway

Необов’язкові:

- `PAYMENT_LINK` — посилання на оплату 399 грн
- `COURSE_LEAD_URL` — посилання на заявку на велике навчання
- `PRODUCT_PRICE_UAH` — ціна продукту, за замовчуванням 399

## Запуск

Railway запускає процес через Procfile:

```bash
worker: python main.py
```

## Що змінено

- Меню перебудовано під воронку «Товарка START»
- Додано блок «Мій перший запуск»
- Додано блок «Створити мій запуск»
- Додано кейси, типові помилки, підводку на навчання
- Залишено адмінку, доступи, OpenAI, аналіз фото, калькулятор, Rozetka/Prom
